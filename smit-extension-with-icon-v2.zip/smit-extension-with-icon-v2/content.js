(function () {
    'use strict';

    const RATE = 2.53;
    const SYMBOL = ' $';

    const usdRegex = /((?:\d{1,3}(?:[.\u202F]\d{3})*),\d{2})\s?\$/g;

    function convertUSDText(text) {
        return text.replace(usdRegex, (_, numberStr) => {
            const cleanNum = parseFloat(numberStr.replace(/[.\u202F]/g, '').replace(',', '.'));
            if (isNaN(cleanNum)) return _;
            const result = cleanNum * RATE;
            return format(result);
        });
    }

    function format(number) {
        return number.toLocaleString('de-DE', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }) + SYMBOL;
    }

    function replaceTextNodes() {
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        let node;
        while ((node = walker.nextNode())) {
            if (node.parentElement && node.parentElement.dataset.usdConverted === "true") continue;
            if (node.nodeValue.includes('$')) {
                const newText = convertUSDText(node.nodeValue);
                if (newText !== node.nodeValue) {
                    node.nodeValue = newText;
                    if (node.parentElement) {
                        node.parentElement.dataset.usdConverted = "true";
                    }
                }
            }
        }
    }

    const observer = new MutationObserver(() => replaceTextNodes());
    observer.observe(document.body, { childList: true, subtree: true });

    replaceTextNodes();
})();